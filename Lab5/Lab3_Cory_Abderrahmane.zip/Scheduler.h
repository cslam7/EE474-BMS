#ifndef Scheduler_H_
#define Scheduler_H_


#include <stdlib.h>
#include <stdbool.h>
#include <Arduino.h>
#define NUMTASKS 6

void scheduler(void* mData1, void* mData2);

#endif
